//1 задание. Проверка чисел

// function checkNumber(number) {
//     if (number > 0) {
//         console.log("Число положительное");
//     } else if (number < 0) {
//         console.log("Число отрицательное");
//     } else {
//         console.log("Это ноль");
//     }

//     if (number % 2 === 0) {
//         console.log("Число чётное");
//     } else {
//         console.log("Число нечётное");
//     }
// }
// checkNumber(8);

//2 задание. Работа с массивом
const numbers = [4, 8, 15, 16, 23, 42];

let sum = 0;
let max = numbers[0];
let biggerThan10 = [];

for (let i = 0; i < numbers.length; i++) {
    sum = sum + numbers[i];

    if (numbers[i] > max) {
        max = numbers[i];
    }
    if (numbers[i] > 10) {
        biggerThan10.push(numbers[i]);
    }
}

console.log("Сумма:", sum);
console.log("Самое большое число:", max);
console.log("Числа больше 10:", biggerThan10);

//3 задание.Список учеников
// const students = [
//     { name: "Анна", grade: 9 },
//     { name: "Иван", grade: 7 },
//     { name: "Мария", grade: 10 },
//     { name: "Пётр", grade: 6 },
//     { name: "Олег", grade: 8 }
// ];

// const minGrade = 7;
// let sum = 0;
// console.log("Ученики с оценкой выше", minGrade + ":");

// for (let i = 0; i < students.length; i++) {
//     sum = sum + students[i].grade;
//     if (students[i].grade > minGrade) {
//         console.log(students[i].name, "-", students[i].grade);
//     }
// }

// const average = sum / students.length;
// console.log("Средняя оценка:", average);

//4 задание. Угадай число
// function guessNumber() {
//     const randomNumber = Math.floor(Math.random() * 10) + 1;
//     const userNumber = Number(prompt("Угадайте число от 1 до 10:"));

//     if (userNumber === randomNumber) {
//         console.log("Поздравляем! Вы угадали!");
//     } else if (userNumber < randomNumber) {
//         console.log("Загаданное число больше");
//         console.log("Было загадано:", randomNumber);
//     } else {
//         console.log("Загаданное число меньше");
//         console.log("Было загадано:", randomNumber);
//     }
// }

// guessNumber();
